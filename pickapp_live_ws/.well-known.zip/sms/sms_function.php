<?php

require_once 'telerivet/telerivet.php';

// $content = "Hello ICP";
// $number = "09171659944";

// $send = sendSMS($content, $number);

function sendSMS($content, $number){
    $YOUR_API_KEY = 'Wlaea_Dk8St7rzqBjqcaItACIg5TbLTSGIEy';
    $project_id = 'PJ4dd2e4557716eaa8';
    
    $tr = new Telerivet_API($YOUR_API_KEY);
    $project = $tr->initProjectById($project_id);
    
    $sent_msg = $project->sendMessage(array(
        'route_id' => 'PN056c944b92ebe894',
        'content' => $content, 
        'to_number' => $number
    ));
}