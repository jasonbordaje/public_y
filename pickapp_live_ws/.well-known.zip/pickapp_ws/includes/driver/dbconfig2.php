<?php
$servername2 = 'localhost';
$username2 = 'yellohot_yellox';
$password2 = '3aFchBj}.0=!';
$dbname2 = 'yellohot_yelloxdb';
$conn2 = new mysqli($servername2, $username2, $password2, $dbname2);
?>