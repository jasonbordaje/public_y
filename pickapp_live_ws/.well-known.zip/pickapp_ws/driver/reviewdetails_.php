<?php
include '../includes/dbconfig2.php';
include '../includes/driver/function.php';

$headerid = $_REQUEST['headerid'];

if (empty($headerid)) {
	session_start();
	$headerid = $_SESSION['headerid'];
}

$query2 = "SELECT DISTINCT * FROM request_details a, delivery_tracking b, request_header c, package_type d WHERE a.request_header_id = $headerid AND c.id = $headerid AND d.id = a.package_type LIMIT 0,1";

$query2 = $conn2->query($query2);
$numrows = mysqli_num_rows($query2);

if($numrows > 0){
	$row2 = mysqli_fetch_assoc($query2);
		echo json_encode($row2);	
}
?>