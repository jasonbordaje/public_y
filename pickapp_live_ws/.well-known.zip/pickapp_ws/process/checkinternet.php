<?php
echo 'Connected';
?>