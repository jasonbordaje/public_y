<?php
include '../includes/dbconfig2.php';
include '../includes/function.php';

echo "review";
?>