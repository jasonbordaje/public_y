function timedCount() {
  var xhr = new XMLHttpRequest();
  xhr.open('POST', 'http://admin.yellox.ph/autoassign.php');
  xhr.onload = function() {
      if (xhr.status === 200) {
          console.log(xhr.responseText);
      }
      else {
          console.log('Request failed.  Returned status of ' + xhr.status);
      }
  };
  xhr.send();
  setTimeout("timedCount()",500);
}

timedCount();