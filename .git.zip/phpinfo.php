<?php


phpinfo();

?>