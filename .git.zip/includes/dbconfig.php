<?php

$servername = "localhost";
$username = "yellohot_yellox";
$password = "3aFchBj}.0=!";
$dbname = "yellohot_yelloxdb";

$conn = new mysqli($servername, $username, $password, $dbname);


?>	